#include <stdio.h>
#include <stdlib.h>

typedef struct ///intr un camp de pixel sa am toate canalele de culoare R,G,B
{
    unsigned char B;
    unsigned char G;
    unsigned char R;
}pixel;

typedef struct
{
    unsigned int ID;
    unsigned int SIZE_OF_BMP;
    unsigned int APP1;
    unsigned int APP2;
    unsigned int OFFSET;
    unsigned int NUMBER_OF_BYTES;
    unsigned int WIDTH;
    unsigned int HEIGHT;
    unsigned int NUMBER_OF_COLOR;
    unsigned int NUMBER_OF_BITS;
    unsigned int NAME_OF;
    unsigned int SIZE_OF_THE_RAW;
    unsigned int RESOLUTION_HORIZONTAL;
    unsigned int RESOLUTION_VERTICAL;
    unsigned int NUMBER_OF_COLORS;
    unsigned int IMPORTANT_COLORS;
}header;

typedef struct
{
    header img; /// salveaza toate detaliile din header despre img
    pixel * pix_color; ///vector de liniarizare pt retinerea pixelilor
    int cod_error;
}image;

void nr_pixeli_imagine(char* nume_img, char* nume_destinatie)
{
   FILE *fin, *fout;
   unsigned int dim_img, latime_img, inaltime_img;
   unsigned char pRGB[3], header[54], aux;

   printf("nume_img = %s \n",nume_img);

   fin = fopen(nume_img, "rb");
   if(fin == NULL) {
   		printf("nu am gasit imaginea sursa din care citesc");
   		return;
   	} else {
   	    printf("%s", nume_img);
   	    printf("\n");
   	}

   fout = fopen(nume_destinatie, "wb+");

   fseek(fin, 2, SEEK_SET);
   fread(&dim_img, sizeof(unsigned int), 1, fin);
   printf("Dimensiunea imaginii in octeti: %u\n", dim_img);

   fseek(fin, 18, SEEK_SET);
   fread(&latime_img, sizeof(unsigned int), 1, fin);
   fread(&inaltime_img, sizeof(unsigned int), 1, fin);
   printf("Dimensiunea imaginii in pixeli (latime x inaltime): %u x %u\n",latime_img, inaltime_img);


	fseek(fin,0,SEEK_SET);
	unsigned char c;
	while(fread(&c,1,1,fin)==1)
	{
		fwrite(&c,1,1,fout);
		fflush(fout); ///goleste buff er
	}
	fclose(fin);

	int padding;
    if(latime_img % 4 != 0)
        padding = 4 - (3 * latime_img) % 4;
    else
        padding = 0;

    printf("padding = %d \n",padding);

	fseek(fout, 54, SEEK_SET);
	int i,j;
	for(i = 0; i < inaltime_img; i++)
	{
		for(j = 0; j < latime_img; j++)
		{
			fread(pRGB, 3, 1, fout);
        	fseek(fout, -3, SEEK_CUR);
        	fwrite(pRGB, 3, 1, fout);
        	fflush(fout);
		}
		fseek(fout,padding,SEEK_CUR);
	}
	fclose(fout);
};


image incarca_imagine (char *nume_fisier_sursa) ///imaginea se liniarizeaza
{
        image aux;
        FILE *fin;
        int latime_img, inaltime_img;
        pixel *L; ///vector de tip pixel

        fin = fopen(nume_fisier_sursa, "rb");

        if(fin == NULL)
        {
            aux.cod_error=-1;
            printf("Nu am putut gasi imaginea");
            return aux;
        }
        header variabila;

        fread(&variabila.ID, 2, 1, fin);
        fread(&variabila.SIZE_OF_BMP, 4, 1, fin);
        fread(&variabila.APP1, 2, 1, fin);
        fread(&variabila.APP2, 2, 1, fin);
        fread(&variabila.OFFSET, 4, 1, fin);
        fread(&variabila.NUMBER_OF_BYTES, 4, 1, fin);
        fread(&variabila.WIDTH, 4, 1, fin);
        fread(&variabila.HEIGHT, 4, 1, fin);
        fread(&variabila.NUMBER_OF_COLOR, 2, 1, fin);
        fread(&variabila.NUMBER_OF_BITS, 2, 1, fin);
        fread(&variabila.NAME_OF, 4, 1, fin);
        fread(&variabila.SIZE_OF_THE_RAW, 4, 1, fin);
        fread(&variabila.RESOLUTION_HORIZONTAL, 4, 1, fin);
        fread(&variabila.RESOLUTION_VERTICAL, 4, 1, fin);
        fread(&variabila.NUMBER_OF_COLORS, 4, 1, fin);
        fread(&variabila.IMPORTANT_COLORS, 4, 1, fin);
        aux.img = variabila;
        latime_img=aux.img.WIDTH;
        inaltime_img=aux.img.HEIGHT;

        unsigned int padding;
        if(latime_img % 4 != 0)
            padding = 4 - (3 * latime_img) % 4;
        else
            padding = 0;


        fseek(fin, 54, SEEK_SET); ///sare peste octeti pt ca header
        int i, j;
        L=(pixel*) malloc (latime_img*inaltime_img*sizeof(pixel)); ///in L e img liniarizata

        for(i=1; i<=aux.img.HEIGHT; i++)
        {
            fseek(fin, - i*aux.img.WIDTH * sizeof(pixel) - i * padding, SEEK_END); ///urc o linie si ma duce la prima coloana
            for(j=0; j<aux.img.WIDTH; j++)
            {
                fread(&L[(i-1)*aux.img.WIDTH+j],sizeof(pixel),1,fin); /// citeste de pe ultima linie, prima
            }
        }

         fclose(fin);
         aux.pix_color=L;
         return aux;
}

pixel xor(pixel A,pixel B) ///XOR
{
   pixel C;
   C.R=A.R^B.R;
   C.G=A.G^B.G;
   C.B=A.B^B.B;
   return C;
}

unsigned int XORSHIFT32(unsigned int r) /// genereaza nr aleatoare prin op pe biti, shift ari si xor ari
{
r = r^r<<13;
r = r^r>>17;
r = r^r<<5;
return r;
}

union pxorx /// unionul ma ajuta sa ccesez octetii unui intreg
{
   unsigned int p;
   unsigned char c[4];
};

void salvare_imagine(char *nume_fisier_sursa, image aux)
{
        FILE *fin;
        int latime_img, inaltime_img;
        pixel *L = aux.pix_color;

        fin = fopen(nume_fisier_sursa, "wb");

        if(fin == NULL)
        {
            printf("Nu am putut gasi imaginea");
            return ;
        }
        header variabila = aux.img;


        fwrite(&variabila.ID, 2, 1, fin);
        fflush(fin);
        fwrite(&variabila.SIZE_OF_BMP, 4, 1, fin);
        fflush(fin);
        fwrite(&variabila.APP1, 2, 1, fin);
        fflush(fin);
        fwrite(&variabila.APP2, 2, 1, fin);
        fflush(fin);
        fwrite(&variabila.OFFSET, 4, 1, fin);
        fflush(fin);
        fwrite(&variabila.NUMBER_OF_BYTES, 4, 1, fin);
        fflush(fin);
        fwrite(&variabila.WIDTH, 4, 1, fin);
        fflush(fin);
        fwrite(&variabila.HEIGHT, 4, 1, fin);
        fflush(fin);
        fwrite(&variabila.NUMBER_OF_COLOR, 2, 1, fin);
        fflush(fin);
        fwrite(&variabila.NUMBER_OF_BITS, 2, 1, fin);
        fflush(fin);
        fwrite(&variabila.NAME_OF, 4, 1, fin);
        fflush(fin);
        fwrite(&variabila.SIZE_OF_THE_RAW, 4, 1, fin);
        fflush(fin);
        fwrite(&variabila.RESOLUTION_HORIZONTAL, 4, 1, fin);
        fflush(fin);
        fwrite(&variabila.RESOLUTION_VERTICAL, 4, 1, fin);
        fflush(fin);
        fwrite(&variabila.NUMBER_OF_COLORS, 4, 1, fin);
        fflush(fin);
        fwrite(&variabila.IMPORTANT_COLORS, 4, 1, fin);
        fflush(fin);

        latime_img=aux.img.WIDTH;
        inaltime_img=aux.img.HEIGHT;

        unsigned int padding;
        if(latime_img % 4 != 0)
            padding = 4 - (3 * latime_img) % 4;
        else
            padding = 0;

        fseek(fin, 54, SEEK_SET);
        int i, j;
        unsigned char tmp=0;
        for(i=inaltime_img-1; i>=0;i--) ///ia de la ultima linie la prima din vectorul liniarizat si o scrie in fisier
        {
            fwrite(aux.pix_color+(i*latime_img), latime_img*sizeof(pixel),1,fin);
            if(padding!=0)
                fwrite(&tmp,1,padding,fin);
        }

        fclose(fin);
        aux.pix_color=L;
}


void x_patrat(char *nume_fisier_sursa)
{
    FILE *f;
    f = fopen("chi_square.txt", "w");

   unsigned int *v=(unsigned int *)malloc(sizeof(unsigned int)*256);
    for(int i=0; i<=255; i++)
        v[i]=0;
    image aux=incarca_imagine(nume_fisier_sursa);

    for(int i=0; i< aux.img.WIDTH*aux.img.HEIGHT; i++)
        v[aux.pix_color[i].R]++;

    double f_barat=aux.img.WIDTH*aux.img.HEIGHT/256.0;


    double suma=0;
    for(int i=0; i<=255; i++)
        suma=suma+((v[i]-f_barat)*(v[i]-f_barat))/f_barat;
    printf("%lf",suma);
    fprintf(f,"R: %lf\n", suma);

    for(int i=0; i<=255; i++)
        v[i]=0;
    for(int i=0; i< aux.img.WIDTH*aux.img.HEIGHT; i++)
        v[aux.pix_color[i].G]++;
    f_barat=aux.img.WIDTH*aux.img.HEIGHT/256;
    suma=0;
    for(int i=0; i<=255; i++)
        suma=suma+((v[i]-f_barat)*(v[i]-f_barat))/f_barat;
    printf("%lf",suma);
    fprintf(f,"G: %lf\n", suma);

    for(int i=0; i<=255; i++)
        v[i]=0;
    for(int i=0; i< aux.img.WIDTH*aux.img.HEIGHT; i++)
        v[aux.pix_color[i].B]++;
    f_barat=aux.img.WIDTH*aux.img.HEIGHT/256;
    suma=0;
    for(int i=0; i<=255; i++)
        suma=suma+((v[i]-f_barat)*(v[i]-f_barat))/f_barat;
    printf("%lf",suma);
    fprintf(f,"B: %lf\n", suma);
    fclose(f);
}

void x_patrat2(char *nume_fisier_sursa)
{
    FILE *f;
    f = fopen("chi_square2.txt", "w");

   unsigned int *v=(unsigned int *)malloc(sizeof(unsigned int)*256);
    for(int i=0; i<=255; i++)
        v[i]=0;
    image aux=incarca_imagine(nume_fisier_sursa);

    for(int i=0; i< aux.img.WIDTH*aux.img.HEIGHT; i++)
        v[aux.pix_color[i].R]++;

    double f_barat=aux.img.WIDTH*aux.img.HEIGHT/256.0;


    double suma=0;
    for(int i=0; i<=255; i++)
        suma=suma+((v[i]-f_barat)*(v[i]-f_barat))/f_barat;
    printf("%lf",suma);
    fprintf(f,"R: %lf\n", suma);

    for(int i=0; i<=255; i++)
        v[i]=0;
    for(int i=0; i< aux.img.WIDTH*aux.img.HEIGHT; i++)
        v[aux.pix_color[i].G]++;
    f_barat=aux.img.WIDTH*aux.img.HEIGHT/256;
    suma=0;
    for(int i=0; i<=255; i++)
        suma=suma+((v[i]-f_barat)*(v[i]-f_barat))/f_barat;
    printf("%lf",suma);
    fprintf(f,"G: %lf\n", suma);

    for(int i=0; i<=255; i++)
        v[i]=0;
    for(int i=0; i< aux.img.WIDTH*aux.img.HEIGHT; i++)
        v[aux.pix_color[i].B]++;
    f_barat=aux.img.WIDTH*aux.img.HEIGHT/256;
    suma=0;
    for(int i=0; i<=255; i++)
        suma=suma+((v[i]-f_barat)*(v[i]-f_barat))/f_barat;
    printf("%lf",suma);
    fprintf(f,"B: %lf\n", suma);
    fclose(f);
}


 void DrawWindow(image imaginica, int x, int y, int patternHeight, int patternWidth, pixel pixel_color)
{

	for (int i = x; i < x + patternHeight + 1; i++)
		imaginica.pix_color[i * imaginica.img.WIDTH + y] = imaginica.pix_color[i * imaginica.img.WIDTH + y + patternWidth] = pixel_color;

	for (int j = y; j < y + patternWidth + 1; j++)
		imaginica.pix_color[x * imaginica.img.WIDTH + j] = imaginica.pix_color[(x + patternHeight) * imaginica.img.WIDTH + j] = pixel_color;
}

 typedef struct
 {
     double corr;
     int poz;

 }detectie;

 int cmp(const void *a, const void *b)
 {
     detectie *x=(detectie*)a;
     detectie *y=(detectie*)b;
     if(x->corr < y->corr)
        return -1;
     else
        return 1;
 }

 void sorteaza_detectii(detectie * tablou, int n )
 {
     qsort(tablou,sizeof(detectie),n,cmp);
 }

void criptare(image nume, unsigned int r, unsigned int sv)
 {
     int *R=(int *)malloc(sizeof(int)*2*nume.img.HEIGHT*nume.img.WIDTH-1); ///w*h-1 e pt permutare si w*h e pt xor are
     R[0]=XORSHIFT32(r); ///primul nr pseudoaleator

     for(int i=1; i<2*nume.img.HEIGHT*nume.img.WIDTH; i++)
     {
         R[i]=XORSHIFT32(R[i-1]);
     }
     unsigned int n,*p,k=0;
        p=(unsigned int*)malloc(nume.img.HEIGHT*nume.img.WIDTH*sizeof(unsigned int)); ///permutare
        n= nume.img.HEIGHT*nume.img.WIDTH;
        unsigned int i;
        for( i=0; i<n; i++)
            p[i]=i; /// permutarea identica
        for(i=n-1; i>=1; i--)
        {
            r=R[k]%(i+1); /// genereaza o permutare ///pune restul impartirii la nr aleator la pozitia+1
            pixel aux=nume.pix_color[i]; ///interchinba elementele conform permutarii generate
            nume.pix_color[i]=nume.pix_color[r];
            nume.pix_color[r]=aux;
            k++;
        }
     union pxorx t;
     t.p=sv;
     union pxorx g;
     g.p=R[0];
     nume.pix_color[0].R=nume.pix_color[0].R^t.c[2]^g.c[2]; ///foloseste al treilea octet din sv si al treilea octet din nr generat aleator
     nume.pix_color[0].G=nume.pix_color[0].G^t.c[1]^g.c[1];
     nume.pix_color[0].B=nume.pix_color[0].B^t.c[0]^g.c[0];
     for(int i=1; i<nume.img.HEIGHT*nume.img.WIDTH; i++)
     {
        g.p=R[i];
        nume.pix_color[i].R=nume.pix_color[i].R^nume.pix_color[i-1].R^g.c[2];
        nume.pix_color[i].G=nume.pix_color[i].G^nume.pix_color[i-1].G^g.c[1];
        nume.pix_color[i].B=nume.pix_color[i].B^nume.pix_color[i-1].B^g.c[0];
     }
 }

 void decriptare(image nume, unsigned int r, unsigned int sv)
 {
     int *R=(int *)malloc(sizeof(int)*2*nume.img.HEIGHT*nume.img.WIDTH-1);
     R[0]=XORSHIFT32(r);
     for(int i=1; i<2*nume.img.HEIGHT*nume.img.WIDTH; i++)
     {
         R[i]=XORSHIFT32(R[i-1]);
     }
     unsigned char x = (sv >> (8*0)) & 0xff; ///BAG primul octet din sv
     unsigned char y = (sv >> (8*1)) & 0xff;
     unsigned char z = (sv >> (8*2)) & 0xff;
     unsigned char x1 = (R[0] >> (8*0)) & 0xff; /// aici baga primul octet din nr generat aleator
     unsigned char y1 = (R[0] >> (8*1)) & 0xff;
     unsigned char z1 = (R[0] >> (8*2)) & 0xff;
     pixel aux=nume.pix_color[0]; ///copie prim pixel inainte de decriptare


     nume.pix_color[0].R=nume.pix_color[0].R^x^x1; ///foloseste primul octet din sv si primul octet in nr generat aleator
     nume.pix_color[0].G=nume.pix_color[0].G^y^y1;
     nume.pix_color[0].B=nume.pix_color[0].B^z^z1;
     for(int i=1; i< nume.img.HEIGHT*nume.img.WIDTH; i++)
     {
        pixel aux2=aux;
        aux=nume.pix_color[i];
        unsigned char x1 = (R[i] >> (8*0)) & 0xff; /// aici baga primul octet din nr generat aleator
        unsigned char y1 = (R[i] >> (8*1)) & 0xff;
        unsigned char z1 = (R[i] >> (8*2)) & 0xff;
        nume.pix_color[i].R=nume.pix_color[i].R^aux2.R^x1;
        nume.pix_color[i].G=nume.pix_color[i].G^aux2.G^y1;
        nume.pix_color[i].B=nume.pix_color[i].B^aux2.B^z1;
     }
     /// dupa asta ar trb sa apare permutarea inversa
 }


int main()
{
    char nume_img[]="peppers.bmp";
    char nume_destinatie[]="enc_peppers.bmp";
    char decriptat[]="img_decript.bmp";

   nr_pixeli_imagine(nume_img, nume_destinatie);

   image I = incarca_imagine(nume_img);

    if(I.cod_error == -1)
        return 0;

    criptare(I,123456789,987654321);
    x_patrat2(nume_destinatie);
    salvare_imagine(nume_destinatie,I);

    image J=incarca_imagine(nume_destinatie);
    decriptare(J,123456789,987654321);
    salvare_imagine(decriptat,J);

    x_patrat(nume_img);

    return 0;
}
